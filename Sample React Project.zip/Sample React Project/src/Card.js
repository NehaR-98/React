import "./Card.css";

function Card() {
    return <div className="card"></div>
}

export default Card;